ln -s /users/kdld047/igv/genomes/hg19_COSMIC.bed
ln -s /users/kdld047/igv/genomes/hg19_COSMIC.bed.idx
ln -s /users/kdld047/igv/genomes/hg19_COSMIC_NoLarger25bpDel.bed
ln -s /users/kdld047/igv/genomes/hg19_COSMIC_NoLarger25bpDel.bed.idx
ln -s /users/kdld047/igv/genomes/hg19_COSMIC_NoLarger25bpDel_NoSilent.bed
ln -s /users/kdld047/igv/genomes/hg19_COSMIC_NoLarger25bpDel_NoSilent.bed.idx
ln -s /users/kdld047/igv/genomes/hg19_GC.bed
ln -s /users/kdld047/igv/genomes/hg19_GC.bed.idx
ln -s /users/kdld047/igv/genomes/hg19_MapabilityUniqueness35bp.bigWig
ln -s /users/kdld047/igv/genomes/hg19_snp135.bed
ln -s /users/kdld047/igv/genomes/hg19_snp135.bed.idx
ln -s /users/kdld047/igv/genomes/hg19_snp135_clin.bed
ln -s /users/kdld047/igv/genomes/hg19_snp135_clin.bed.idx

